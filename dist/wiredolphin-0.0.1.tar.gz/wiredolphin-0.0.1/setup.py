# -*- coding: utf-8 -*-

from distutils.core import setup

setup(name='wiredolphin',
      version='0.0.1',
      description='Network capture.',
      author='laixintao',
      author_email='laixintao1995@163.com',
      url='https://www.python.org/',
      packages=['wiredolphin'],
     )
